export interface ITruckItem {
  key: number;
  code: string;
  name: string;
  length: number;
  width: number;
  hight: number;
  maxLoad: number;
  quantity: number;
}
