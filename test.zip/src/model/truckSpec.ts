export interface TruckSpec {
  code: string;
  amount: number;
}
