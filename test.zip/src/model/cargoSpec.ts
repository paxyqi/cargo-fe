export interface CargoSpec {
  code: string;
  amount: number;
}
