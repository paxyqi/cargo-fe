export interface Orientation {
  index: number;
  bearing: boolean;
  bearinglevel: number;
  stackinglimit: number;
}
